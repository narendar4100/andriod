package com.example.macstudent.shopfast;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ViewOrderActivity extends AppCompatActivity {
    TextView txtPrdt,txtQunatity,txttotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);
        SharedPreferences sp = getSharedPreferences("com.jk.sirra.shared", Context.MODE_PRIVATE);


       txtPrdt = findViewById(R.id.edtProductName);
       txtPrdt.setText(sp.getString("product name", "Data Missing"));

        txtQunatity = findViewById(R.id.txtQunatity);
        txtPrdt.setText(sp.getString("product name", "Data Missing"));

        txttotal = findViewById(R.id.txttotal);
        txttotal.setText(sp.getString("product name", "Data Missing"));


    }
}
