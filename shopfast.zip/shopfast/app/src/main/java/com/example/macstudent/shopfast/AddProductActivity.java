package com.example.macstudent.shopfast;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class AddProductActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText edtProductName,edtCmpnyName,edtPrice,edtquantity;
    Spinner spnCtg;
    Button btnOrder;
    String[] ctgs = { "Home needs", "kitchen wear ", "vegitable", "dairy products"};
    String selectedctg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);


    }

    @Override
    public void onClick(View v) {
        edtPrice = findViewById(R.id.edtPrice);
        edtProductName = findViewById(R.id.edtProductName);
        edtCmpnyName = findViewById(R.id.edtCmpnyName);
        edtquantity = findViewById(R.id.edtquantity);
        spnCtg = findViewById(R.id.spnCtg);
        ArrayAdapter ctgAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,ctgs);
        spnCtg.setAdapter(ctgAdapter);
        spnCtg.setOnItemSelectedListener(this);


        if(v.getId() == btnOrder.getId()) {
            SharedPreferences sp = getSharedPreferences("com.jk.sirra.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("productName", edtProductName.getText().toString());
            edit.putString("companyName", edtCmpnyName.getText().toString());
            edit.putString("price", edtPrice.getText().toString());
            edit.putString("qantity", edtquantity.getText().toString());
            edit.putString("category", selectedctg);
            edit.commit();
            startActivity(new Intent(getApplicationContext(), ViewOrderActivity.class));
        }



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.getId() == spnCtg.getId()) {
            selectedctg = ctgs[position];
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
