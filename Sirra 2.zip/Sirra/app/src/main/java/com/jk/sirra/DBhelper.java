package com.jk.sirra;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBhelper extends SQLiteOpenHelper {
    final static String DBName = "parkingDB";
    final static String TBName_userinfo = "userInfo";

    public DBhelper(Context context) {

        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
      try{
          String CREATE_TABLE ="CREATE TABLE "+ TBName_userinfo + "(Name varchar(100), Phone varchar(20), "
                  + "Email varchar(50) PRIMARY KEY, Password varchar(20)," + "DOB varchar(20))";
          Log.v("DBhelper", CREATE_TABLE);
          db.execSQL(CREATE_TABLE);

       }catch(Exception e){
          Log.e("DBhelper",e.getMessage());

      }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        try{
            db.execSQL("DROP TABLE IF EXISTS " + TBName_userinfo);
            onCreate(db);

        }catch(Exception e){
            Log.e("DBhelper",e.getMessage());

        }
    }
}
