package com.jk.sirra;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnCall , btnSms, btnEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
        btnCall= findViewById(R.id.btnCall);
        btnCall.setOnClickListener(this);

        btnSms = findViewById(R.id.btnSms);
        btnSms.setOnClickListener(this);

        btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnCall:
                makeCall();
                break;
            case R.id.btnSms:
                sendSms();
                break;
            case R.id.btnEmail:
                sendEmail();
                break;


        }


    }


    private void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:123344567"));

        if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)!= getPackageManager().PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),"call permission denied", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(callIntent);

    }
      private void sendSms(){
       Intent smsIntent = new Intent(Intent.ACTION_SEND, Uri.parse("smsto:2354665"));
       smsIntent.putExtra("sms_body", "this is atest message");
     }
     private void sendEmail(){

        Intent emailIntent = new Intent (Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"abc@gmail.com","bdfd@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"test message");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "this is a test email from mad class");

        emailIntent.setType("*/*");

        startActivity(Intent.createChooser(emailIntent, "select email profile"));


    }
}