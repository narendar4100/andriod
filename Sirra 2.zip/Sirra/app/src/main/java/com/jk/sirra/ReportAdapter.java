package com.jk.sirra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.jk.sirra.R;

public class ReportAdapter extends BaseAdapter {
    LayoutInflater inflater;
    Context context;


        String[] carPlate = { "ABC0123","ASDF211","JkP7191"};
        String[] amount = {"$10","$20","$30"};
        String[] lots = {"A", "J", "P"};
        String[] spots = {"101","10","23"};
        String[] dateTime={"06-27-2018 12:30PM","06-27-2018 1:20PM","06-27-2018 3:30PM"};
    ReportAdapter(Context context){
        this.context = context;
        inflater= LayoutInflater.from(context);



    }
    @Override
    public int getCount() {
        return carPlate.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View  getView(final int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.list_report_item, null);

       TextView txtCarplate = convertView.findViewById(R.id.txtCarPlate);
        txtCarplate.setText(carPlate[position]);

        TextView txtAmount = convertView.findViewById(R.id.txtAmount);
        txtAmount.setText("$"+ amount[position]);

        TextView txtDateTime = convertView.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);

        TextView txtlot = convertView.findViewById(R.id.txtLot);
        txtlot.setText("Lot:"+lots[position]);

        TextView txtspot = convertView.findViewById(R.id.txtSpot);
        txtspot.setText("spot:"+spots[position]);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Item" + position +"selected", Toast.LENGTH_SHORT).show();



                }

        });
        return convertView;

    }
}
