package com.example.macstudent.thinesipoo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class AppetizerActivity extends AppCompatActivity implements View.OnClickListener{
    ImageButton btnMunch,btnCp,btnSm,btnCw;
    TextView txtPrice1, txtPrice2, txtcp,txtCw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appetizer);
        btnMunch = findViewById(R.id.btnMunch);
        btnMunch.setOnClickListener(this);
        btnCp = findViewById(R.id.btnCp);
        btnCp.setOnClickListener(this);
        btnCw = findViewById(R.id.btnCw);
        btnCw.setOnClickListener(this);
        btnSm = findViewById(R.id.btnSm);
        btnSm.setOnClickListener(this);
        txtPrice1 = findViewById(R.id.txtPrice1);
        txtPrice1.setText("manchuria ");


    }

    @Override
    public void onClick(View v) {

        if(v.getId() == btnMunch.getId()) {
            SharedPreferences sp = getSharedPreferences("com.example.macstudent.thinesipoo.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("order", txtPrice1.getText().toString());

            edit.commit();

            startActivity(new Intent(getApplicationContext(), OrderHistoryActivity.class));

        }



    }
}
