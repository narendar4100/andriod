package com.example.macstudent.thinesipoo;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class OrderHistoryActivity extends AppCompatActivity {
    TextView txtPrice1,txtCp,txtSm, txtCw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        SharedPreferences sp = getSharedPreferences("com.jk.sirra.shared", Context.MODE_PRIVATE);

        txtPrice1 = findViewById(R.id.txtorder);
        txtPrice1.setText(sp.getString("DateTime","Manchuria ordered"));

    }
}
